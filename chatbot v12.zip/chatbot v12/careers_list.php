<?php
    include 'header.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <h1>Available Careers</h1>
    <ul>
        <li>Project Manager<a href='project_manager.php'> Click here</a></li>
        <li>cyber security specialist<a href='cyber_security_specialist.php'> Click here</a></li>
        <li>business Analyst<a href='business_analyst.php'> Click here</a></li>
        <li>API specialist<a href='api_specialist.php'> Click here</a></li>
        <li>AI/ML engineer<a href='AIML_engineer.php'> Click here</a></li>
        <li>Application Support Engineer<a href='application_support_engineer.php'> Click here</a></li>
        <li>Software Tester<a href='software_tester.php'> Click here</a></li>
        <li>Software Developer<a href='software_developer.php'> Click here</a></li>
        <li>Networking Engineer<a href='networking_engineer.php'> Click here</a></li>
        <li>Helpdesk Engineer<a href='helpdesk_engineer.php'> Click here</a></li>
        <li>Project Manager<a href='project_manager.php'> Click here</a></li>
    </ul>
</body>
</html>
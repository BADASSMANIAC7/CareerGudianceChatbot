<!-- footer.php -->
<footer style="text-align:center; padding: 20px;">
    &copy; 2025 Career Portal
</footer>

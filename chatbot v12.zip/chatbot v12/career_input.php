<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career Prediction</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap">

    <!-- Custom Styles -->
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* CSS Variables for Dark Mode */
        :root {
            --bg-color: #1a3c34; /* Dark green background */
            --text-color: #e0eafc; /* Light blue text */
            --container-bg: #2a4d3e; /* Darker green for form container */
            --btn-bg: #28a745; /* Green button */
            --btn-hover-bg: #1e7e34;
            --logout-bg: #dc3545; /* Red logout button */
            --logout-hover-bg: #c82333;
            --header-bg-start: #228b3b; /* Slightly darker green for header */
            --header-bg-end: #155d27;
            --border-color: #4a7066; /* Subtle border for form elements */
            --focus-shadow: rgba(40, 167, 69, 0.5);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--text-color);
        }

        /* Header */
        header {
            position: sticky;
            top: 0;
            background: linear-gradient(90deg, var(--header-bg-start), var(--header-bg-end));
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            animation: slideDown 0.8s ease-out;
        }

        .navbar {
            padding: 15px 0;
        }

        .container {
            max-width: 1200px;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #ffffff;
            transition: color 0.3s ease;
        }

        .navbar-brand:hover {
            color: #ffd700;
        }

        .nav-link {
            color: #ffffff;
            font-weight: 400;
            margin: 0 15px;
            position: relative;
            transition: color 0.3s ease;
        }

        .nav-link:hover {
            color: #ffd700;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background: #ffd700;
            transition: width 0.3s ease;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .navbar-toggler {
            border: none;
            padding: 8px;
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba(255, 255, 255, 0.9)' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
        }

        .navbar-collapse {
            transition: height 0.3s ease, opacity 0.3s ease;
        }

        .navbar-collapse.show {
            opacity: 1;
            background: linear-gradient(90deg, var(--header-bg-start), var(--header-bg-end));
            padding: 10px;
        }

        .btn-logout {
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            background: var(--logout-bg);
            color: #ffffff;
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
        }

        .btn-logout:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.5);
            background: var(--logout-hover-bg);
        }

        .btn-logout:focus {
            outline: 3px solid var(--logout-hover-bg);
            outline-offset: 2px;
        }

        /* Form Container */
        .container.form-container {
            max-width: 600px;
            margin: 100px auto 60px;
            padding: 30px;
            background: var(--container-bg);
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            opacity: 0;
            animation: fadeIn 1s ease-out 0.2s forwards;
        }

        .container h2 {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--text-color);
            opacity: 0;
            animation: slideInUp 0.8s ease-out 0.4s forwards;
        }

        .form-label {
            font-weight: 500;
            color: var(--text-color);
            opacity: 0;
            animation: fadeIn 0.6s ease-out forwards;
        }

        .form-select {
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: #344c46;
            color: var(--text-color);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            opacity: 0;
            animation: fadeIn 0.6s ease-out forwards;
        }

        /* Staggered animation for form elements */
        .mb-3:nth-child(1) .form-label, .mb-3:nth-child(1) .form-select { animation-delay: 0.6s; }
        .mb-3:nth-child(2) .form-label, .mb-3:nth-child(2) .form-select { animation-delay: 0.65s; }
        .mb-3:nth-child(3) .form-label, .mb-3:nth-child(3) .form-select { animation-delay: 0.7s; }
        .mb-3:nth-child(4) .form-label, .mb-3:nth-child(4) .form-select { animation-delay: 0.75s; }
        .mb-3:nth-child(5) .form-label, .mb-3:nth-child(5) .form-select { animation-delay: 0.8s; }
        .mb-3:nth-child(6) .form-label, .mb-3:nth-child(6) .form-select { animation-delay: 0.85s; }
        .mb-3:nth-child(7) .form-label, .mb-3:nth-child(7) .form-select { animation-delay: 0.9s; }
        .mb-3:nth-child(8) .form-label, .mb-3:nth-child(8) .form-select { animation-delay: 0.95s; }
        .mb-3:nth-child(9) .form-label, .mb-3:nth-child(9) .form-select { animation-delay: 1s; }
        .mb-3:nth-child(10) .form-label, .mb-3:nth-child(10) .form-select { animation-delay: 1.05s; }
        .mb-3:nth-child(11) .form-label, .mb-3:nth-child(11) .form-select { animation-delay: 1.1s; }
        .mb-3:nth-child(12) .form-label, .mb-3:nth-child(12) .form-select { animation-delay: 1.15s; }
        .mb-3:nth-child(13) .form-label, .mb-3:nth-child(13) .form-select { animation-delay: 1.2s; }
        .mb-3:nth-child(14) .form-label, .mb-3:nth-child(14) .form-select { animation-delay: 1.25s; }
        .mb-3:nth-child(15) .form-label, .mb-3:nth-child(15) .form-select { animation-delay: 1.3s; }
        .mb-3:nth-child(16) .form-label, .mb-3:nth-child(16) .form-select { animation-delay: 1.35s; }
        .mb-3:nth-child(17) .form-label, .mb-3:nth-child(17) .form-select { animation-delay: 1.4s; }

        .form-select:focus {
            border-color: var(--btn-bg);
            box-shadow: 0 0 8px var(--focus-shadow);
            outline: none;
        }

        .form-select:invalid {
            border-color: var(--logout-bg);
            box-shadow: 0 0 8px rgba(220, 53, 69, 0.5);
        }

        .form-select option {
            background: #344c46;
            color: var(--text-color);
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 8px;
            background: var(--btn-bg);
            color: #ffffff;
            border: none;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
            opacity: 0;
            animation: scaleIn 0.6s ease-out 1.5s forwards;
        }

        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 15px var(--focus-shadow);
            background: var(--btn-hover-bg);
        }

        .btn-submit:focus {
            outline: 3px solid var(--btn-hover-bg);
            outline-offset: 2px;
        }

        .btn-submit::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.5s ease, height 0.5s ease;
        }

        .btn-submit:active::after {
            width: 300px;
            height: 300px;
        }

        .btn-submit.loading::after {
            content: '';
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #fff;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
            margin-left: 8px;
        }

        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #2a4d3e;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--btn-bg);
            border-radius: 4px;
        }

        /* Keyframes */
        @keyframes slideDown {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(0); }
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        @keyframes slideInUp {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
            0% { opacity: 0; transform: scale(0.85); }
            100% { opacity: 1; transform: scale(1); }
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Accessibility */
        @media (prefers-reduced-motion: reduce) {
            header, .container, .container h2, .form-label, .form-select, .btn-submit, .btn-logout {
                animation: none;
                opacity: 1;
                transform: none;
            }
            .btn-submit:hover, .btn-logout:hover, .nav-link:hover {
                transform: none;
                box-shadow: none;
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container.form-container {
                margin: 80px 20px 40px;
                padding: 20px;
            }
            .container h2 {
                font-size: 24px;
            }
            .btn-submit {
                font-size: 16px;
                padding: 10px;
            }
            .navbar-brand {
                font-size: 20px;
            }
            .nav-link {
                margin: 5px 0;
                font-size: 14px;
            }
            .btn-logout {
                margin: 10px 0;
                width: 100%;
                text-align: center;
            }
            .navbar-collapse.show {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container form-container">
        <h2 class="text-center mb-4">Enter Your Skill Levels</h2>

        <form action="career_process.php" method="post">
            <?php
            $skills = [
                "Database Fundamentals" => "database_fundamentals",
                "Computer Architecture" => "computer_architecture",
                "Distributed Computing Systems" => "distributed_computing",
                "Cyber Security" => "cyber_security",
                "Networking" => "networking",
                "Software Development" => "software_development",
                "Programming Skills" => "programming_skills",
                "Project Management" => "project_management",
                "Computer Forensics" => "computer_forensics",
                "Technical Communication" => "technical_communication",
                "AI & ML" => "ai_ml",
                "Software Engineering" => "software_engineering",
                "Business Analysis" => "business_analysis",
                "Communication Skills" => "communication_skills",
                "Data Science" => "data_science",
                "Troubleshooting Skills" => "troubleshooting_skills",
                "Graphics Designing" => "graphics_designing"
            ];

            $levels = ["Not Interested", "Poor", "Beginner", "Average", "Intermediate", "Professional"];

            foreach ($skills as $skillName => $skillKey) {
                echo "<div class='mb-3'>
                        <label class='form-label'>$skillName</label>
                        <select name='$skillKey' class='form-select' required>";
                foreach ($levels as $level) {
                    echo "<option value='$level'>$level</option>";
                }
                echo "</select>
                      </div>";
            }
            ?>

            <button type="submit" class="btn btn-submit mt-3">Predict Career</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>